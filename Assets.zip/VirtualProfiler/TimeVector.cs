﻿using UnityEngine;

namespace Assets.VirtualProfiler
{
    public class TimeVector
    {
        public Vector3 Vector { get; set; }
        public float Time { get; set; }
    }
}