﻿namespace Assets.SmartMenu
{
    public class Padding
    {
        public Padding(int left, int top)
        {
            Left = left;
            Top = top;
        }

        public int Left { get; set; }
        public int Top { get; set; }
    }
}