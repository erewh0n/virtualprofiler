﻿
namespace Assets.SmartMenu
{

    public interface ISmartMenu
    {
        ISmartMenu CreateMenu();
    }

}
